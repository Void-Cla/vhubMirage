// nui/js/app.js — vhub_racha v3 (Mirage Racha)
// L-D8: NUI nao decide. Relay puro de intencao para o servidor.

(() => {
  const state = {
    open: false,
    catalog: [],
    lobbies: [],
    cfg: { brand_name: 'Mirage Racha', brand_tag: 'Liga clandestina', max_fee: 100000 },
    activeTab: 'tracks',
    tracksFilter: '',
    tracksKind: '',
    modal: { track: null, laps: 1, fee: 1000, mode: 'rankeada' },
    editor: { open: false, draft: null },
  };

  const $  = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);
  const el = (tag, attrs, ...children) => {
    const e = document.createElement(tag);
    if (attrs) for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') e.className = v;
      else if (k === 'html') e.innerHTML = v;
      else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2), v);
      else if (k.startsWith('data-') || k === 'colspan' || k === 'title' || k === 'value') e.setAttribute(k, v);
      else e[k] = v;
    }
    for (const c of children) {
      if (c == null) continue;
      e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return e;
  };

  const fmtNum = (n) => {
    const v = Math.max(0, Math.floor(Number(n) || 0));
    return v.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  };
  const fmtMoney = (n) => 'R$ ' + fmtNum(n);
  const fmtTime = (ms) => {
    const n = Math.max(0, Math.floor(Number(ms) || 0));
    const mm = Math.floor(n / 60000);
    const ss = Math.floor((n % 60000) / 1000);
    const mmm = n % 1000;
    return `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}.${String(mmm).padStart(3, '0')}`;
  };
  const fmtDate = (unix) => {
    if (!unix) return '—';
    const d = new Date(unix * 1000);
    return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  };

  const KIND_LABELS = {
    sprint: 'Sprint', circuit: 'Circuito', drag: 'Drag', drift: 'Drift',
    speedtrap: 'Radar', timeattack: 'Contra-relógio', freerun: 'Free Run',
  };
  const KIND_ICONS = {
    sprint: 'fa-solid fa-bolt', circuit: 'fa-solid fa-arrows-rotate',
    drag: 'fa-solid fa-flag-checkered', drift: 'fa-solid fa-wind',
    speedtrap: 'fa-solid fa-gauge-high', timeattack: 'fa-solid fa-stopwatch',
    freerun: 'fa-solid fa-road',
  };

  const POST = (cb, data) =>
    fetch(`https://${typeof GetParentResourceName === 'function'
      ? GetParentResourceName() : 'vhub_racha'}/${cb}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data || {}),
    }).then((r) => r.json().catch(() => ({}))).catch(() => ({}));

  function toast(message, kind = 'info') {
    const icon = kind === 'success' ? 'fa-circle-check'
               : kind === 'error'   ? 'fa-triangle-exclamation'
               :                      'fa-circle-info';
    const t = el('div', { class: `vh-toast ${kind}` },
      el('i', { class: 'fa-solid ' + icon }),
      el('span', null, message));
    $('#toast-stack').appendChild(t);
    setTimeout(() => {
      t.classList.add('fade-out');
      setTimeout(() => t.remove(), 250);
    }, 3500);
  }

  // ─── Mapeamento de erros (PT-BR) ────────────────────────────────────────

  const ERR = {
    sem_sessao:             'Sessão não encontrada.',
    pista_inexistente:      'Pista não encontrada.',
    lobby_fechado:          'Esse lobby já foi iniciado.',
    ja_no_lobby:            'Você já está nesse lobby.',
    ja_em_outra_corrida:    'Você já está em outra corrida.',
    lobby_cheio:            'O lobby está cheio.',
    saldo_insuficiente:     'Saldo insuficiente para a taxa.',
    sem_grid:               'Sem slots de grade disponíveis.',
    jogadores_insuficientes:'Jogadores insuficientes para iniciar.',
    nao_e_lobby:            'Não é mais um lobby aberto.',
    estado_invalido:        'Estado inválido para essa ação.',
    forbidden:              'Operação não permitida.',
    host_left:              'O organizador saiu.',
    fora_da_ready_zone:     'Vá até o ponto de largada para confirmar.',
    fora_do_lobby:          'Você não está nesse lobby.',
    sem_presenca_minima:    'Sem presença mínima confirmada.',
    lobby_expirou:          'Lobby expirou.',
  };
  const errMsg = (raw) => ERR[String(raw || '')] || `Falha: ${raw || 'erro desconhecido'}.`;

  // ─── Render: Pistas ─────────────────────────────────────────────────────

  function renderTracks() {
    const grid = $('#tracks-grid');
    const filter = (state.tracksFilter || '').trim().toLowerCase();
    const kind = state.tracksKind || '';
    let list = state.catalog;
    if (kind) list = list.filter((t) => t.kind === kind);
    if (filter) {
      list = list.filter((t) =>
        t.label.toLowerCase().includes(filter) ||
        (t.district || '').toLowerCase().includes(filter) ||
        (KIND_LABELS[t.kind] || '').toLowerCase().includes(filter));
    }
    $('#tracks-count').textContent = list.length;
    grid.innerHTML = '';
    if (list.length === 0) {
      grid.appendChild(el('div', { class: 'vh-empty' },
        el('i', { class: 'fa-solid fa-road' }),
        'Nenhuma pista encontrada.'));
      return;
    }
    for (const t of list) grid.appendChild(renderTrackCard(t));
  }

  function renderTrackCard(t) {
    const card = el('div', { class: 'vh-card vh-track' });
    const head = el('div', { class: 'vh-track-head' });
    head.appendChild(el('i', { class: (KIND_ICONS[t.kind] || 'fa-solid fa-road'),
                               style: 'color: var(--vh-gold); font-size: 18px;' }));
    head.appendChild(el('div', { class: 'vh-track-title' }, t.label));
    head.appendChild(el('span',
      { class: 'vh-kind-badge' + (t.illegal ? ' illegal' : '') },
      KIND_LABELS[t.kind] || t.kind));
    card.appendChild(head);

    const meta = el('div', { class: 'vh-track-meta' });
    meta.appendChild(el('span', null,
      el('i', { class: 'fa-solid fa-map-marker' }), ' ',
      el('b', null, t.district || '—')));
    meta.appendChild(el('span', null,
      el('i', { class: 'fa-solid fa-flag' }), ' ',
      el('b', null, String(t.cps || 0)), ' CPs'));
    meta.appendChild(el('span', null,
      el('i', { class: 'fa-solid fa-users' }), ' ',
      el('b', null, `${t.min_players}-${t.max_players}`)));
    if (t.laps > 1) {
      meta.appendChild(el('span', null,
        el('i', { class: 'fa-solid fa-arrows-rotate' }), ' ',
        el('b', null, String(t.laps)), ' voltas'));
    }
    if (t.alerts_police) {
      meta.appendChild(el('span', { title: 'Alerta polícia' },
        el('i', { class: 'fa-solid fa-triangle-exclamation' }), ' ',
        el('b', null, 'Polícia')));
    }
    if (t.source === 'custom') {
      meta.appendChild(el('span', { title: 'Pista customizada' },
        el('i', { class: 'fa-solid fa-hammer' }), ' ',
        el('b', null, 'Custom')));
    }
    card.appendChild(meta);

    const foot = el('div', { class: 'vh-track-foot' });
    foot.appendChild(el('span', { class: 'vh-track-fee' },
      t.default_fee > 0 ? fmtMoney(t.default_fee) : 'Grátis'));
    foot.appendChild(el('button', {
      class: 'vh-btn primary small',
      onclick: () => openCreate(t),
    }, el('i', { class: 'fa-solid fa-flag-checkered' }), 'Criar lobby'));
    card.appendChild(foot);
    return card;
  }

  // ─── Render: Lobbies ────────────────────────────────────────────────────

  function renderLobbies() {
    const list = $('#lobbies-list');
    $('#lobby-count').textContent = state.lobbies.length;
    list.innerHTML = '';
    if (state.lobbies.length === 0) {
      list.appendChild(el('div', { class: 'vh-empty' },
        el('i', { class: 'fa-solid fa-flag' }),
        'Nenhum lobby aberto. Crie um na aba "Pistas".'));
      return;
    }
    for (const lb of state.lobbies) list.appendChild(renderLobbyRow(lb));
  }

  function renderLobbyRow(lb) {
    const row = el('div', { class: 'vh-lobby' });
    row.appendChild(el('i', {
      class: KIND_ICONS[lb.kind] || 'fa-solid fa-road',
      style: 'color: var(--vh-gold); font-size: 24px;',
    }));
    const info = el('div', { class: 'vh-lobby-info' });

    const title = el('div', { class: 'vh-lobby-title' }, lb.label || lb.track_id);
    title.appendChild(document.createTextNode(' '));
    title.appendChild(el('span', { class: 'vh-lobby-state ' + lb.state },
      lb.state === 'pending' ? 'Confirmando' : 'Aberto'));
    if (lb.mode === 'treino') {
      title.appendChild(document.createTextNode(' '));
      title.appendChild(el('span', { class: 'vh-lobby-mode' }, 'TREINO'));
    }
    info.appendChild(title);

    const meta = el('div', { class: 'vh-lobby-meta' });
    meta.appendChild(el('span', null,
      KIND_LABELS[lb.kind] || lb.kind, ' · ',
      el('b', null, `${lb.players}/${lb.max_players}`), ' inscritos',
      lb.state === 'pending'
        ? el('span', null, ' · ', el('b', null, String(lb.confirmed || 0)), ' confirmados')
        : null, ' · ',
      el('b', null, fmtMoney(lb.entry_fee || 0)), ' entrada'));
    info.appendChild(meta);
    row.appendChild(info);

    const actions = el('div', { class: 'vh-lobby-actions' });
    actions.appendChild(el('button', {
      class: 'vh-btn primary small',
      onclick: () => POST('join', { inst_id: lb.id }),
    }, el('i', { class: 'fa-solid fa-right-to-bracket' }), 'Entrar'));
    row.appendChild(actions);
    return row;
  }

  // ─── Render: Ranking + Histórico ───────────────────────────────────────

  function renderRanking(rows) {
    const tbody = $('#ranking-tbody');
    tbody.innerHTML = '';
    if (!Array.isArray(rows) || rows.length === 0) {
      tbody.appendChild(el('tr', null,
        el('td', { class: 'vh-table-empty', colspan: 8 },
          'Sem dados ainda. Quando houver corridas, o ranking aparece aqui.')));
      return;
    }
    rows.forEach((r, i) => {
      const placeClass = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';
      tbody.appendChild(el('tr', null,
        el('td', { class: placeClass }, '#' + (i + 1)),
        el('td', null, r.nick || ('char_' + r.char_id)),
        el('td', null, String(r.wins || 0)),
        el('td', null, String(r.podiums || 0)),
        el('td', null, String(r.dnf || 0)),
        el('td', null, r.best_time_ms > 0 ? fmtTime(r.best_time_ms) : '—'),
        el('td', null, fmtNum(r.total_drift || 0)),
        el('td', null, (r.top_speed || 0) + ' km/h')));
    });
  }

  function renderHistory(rows) {
    const tbody = $('#history-tbody');
    tbody.innerHTML = '';
    if (!Array.isArray(rows) || rows.length === 0) {
      tbody.appendChild(el('tr', null,
        el('td', { class: 'vh-table-empty', colspan: 9 }, 'Nenhuma corrida registrada ainda.')));
      return;
    }
    for (const h of rows) {
      tbody.appendChild(el('tr', null,
        el('td', { class: 'when', title: fmtDate(h.started_unix) }, fmtDate(h.started_unix)),
        el('td', null, KIND_LABELS[h.kind] || h.kind),
        el('td', null, h.mode === 'treino' ? 'Treino' : 'Rankeada'),
        el('td', null, h.track_id),
        el('td', null, String(h.players_total || 0)),
        el('td', null, h.winner_nick || ('char_' + h.winner_char)),
        el('td', null, h.winner_time_ms > 0 ? fmtTime(h.winner_time_ms) : '—'),
        el('td', null, fmtMoney(h.pot_total || 0)),
        el('td', null, el('button', {
          class: 'vh-btn ghost small',
          onclick: () => POST('results', { history_id: h.id }),
        }, el('i', { class: 'fa-solid fa-eye' })))));
    }
  }

  // ─── Modal criar lobby ──────────────────────────────────────────────────

  function openCreate(track) {
    state.modal = {
      track, mode: 'rankeada',
      laps: track.laps || 1, fee: track.default_fee || 0,
    };
    $('#modal-track').textContent = track.label + ' (' + (track.district || '—') + ')';
    $('#modal-kind').textContent  = KIND_LABELS[track.kind] || track.kind;
    $('#modal-laps').value = track.laps || 1;
    $('#modal-laps').max   = 10;
    $('#modal-fee').value  = track.default_fee || 0;
    $('#modal-fee').max    = state.cfg.max_fee || 100000;
    $('#modal-mode').value = 'rankeada';
    // TimeAttack/Freerun forçados para treino (sem prêmio)
    if (track.kind === 'timeattack' || track.kind === 'freerun') {
      $('#modal-mode').value = 'treino';
      $('#modal-fee').value = 0;
    }
    $('#modal-create').classList.remove('hidden');
  }
  function closeModal() { $('#modal-create').classList.add('hidden'); }
  function submitCreate() {
    const m = state.modal;
    if (!m.track) return;
    POST('create', {
      track_id: m.track.id,
      mode: $('#modal-mode').value,
      laps: parseInt($('#modal-laps').value, 10) || 1,
      entry_fee: parseInt($('#modal-fee').value, 10) || 0,
    });
    closeModal();
  }

  // ─── Tabs ───────────────────────────────────────────────────────────────

  function switchTab(name) {
    state.activeTab = name;
    $$('.vh-tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
    $$('.vh-tabpanel').forEach((p) => p.classList.toggle('active', p.dataset.tabpanel === name));
    if (name === 'ranking') {
      POST('ranking', { kind: $('#ranking-kind').value || 'sprint',
                        mode: $('#ranking-mode').value || 'wins' });
    } else if (name === 'history') {
      POST('history', { kind: $('#history-kind').value || '',
                        mode: $('#history-mode').value || '' });
    }
  }

  // ─── Editor (NUI envia relays ao server) ────────────────────────────────
  // Iniciar editor: o cliente Lua vai FECHAR este painel automaticamente
  // quando receber EDITOR_OPENED (libera cursor + inputs de veiculo).
  // O painel reabre na fase META (form de metadados) via NUI_OPENED.

  function editorStart() {
    POST('editor_open', {});
    // Nao chamamos switchTab nem toast aqui — o painel vai fechar e o
    // cliente Lua mostra notify nativo "Editor ativo. Use comandos in-game.".
  }

  function editorSave() {
    const payload = {
      id:            ($('#meta-id').value || '').trim(),
      label:         ($('#meta-label').value || '').trim(),
      district:      ($('#meta-district').value || '').trim() || 'Custom',
      kind:          $('#meta-kind').value || 'sprint',
      laps:          parseInt($('#meta-laps').value, 10) || 1,
      default_fee:   parseInt($('#meta-fee').value, 10) || 0,
      limit_seconds: parseInt($('#meta-limit').value, 10) || 300,
      illegal:       $('#meta-illegal').checked === true,
      alerts_police: $('#meta-police').checked === true,
    };
    if (!payload.id) {
      toast('Informe um ID para a pista.', 'error');
      return;
    }
    POST('editor_save', payload);
  }

  // ─── Mensagens do server ────────────────────────────────────────────────

  window.addEventListener('message', (e) => {
    const msg = e.data || {};
    switch (msg.action) {
      case 'open': {
        state.open = true;
        const d = msg.data || {};
        state.catalog = d.catalog || [];
        state.lobbies = d.lobbies || [];
        Object.assign(state.cfg, d.cfg || {});
        $('#brand-tag').textContent = state.cfg.brand_tag || 'Liga clandestina';
        // Mostra bg.png APENAS no painel principal
        $('#vhub-bg').classList.remove('hidden');
        $('#panel').classList.remove('hidden');
        switchTab('tracks');
        renderTracks();
        renderLobbies();
        renderRanking(d.ranking || []);
        renderHistory(d.history || []);
        window.vhubSand && window.vhubSand.start();
        break;
      }
      case 'close': {
        state.open = false;
        $('#panel').classList.add('hidden');
        $('#vhub-bg').classList.add('hidden');
        $('#modal-create').classList.add('hidden');
        window.vhubSand && window.vhubSand.stop();
        break;
      }
      case 'refresh': {
        const d = msg.data || {};
        if (d.lobbies) { state.lobbies = d.lobbies; renderLobbies(); }
        break;
      }
      case 'result': {
        const r = msg.data || {};
        if (r.ok) {
          const k = r.kind || '';
          if      (k === 'create') toast('Lobby criado. Vá ao ponto de largada e confirme presença.', 'success');
          else if (k === 'join')   toast('Você entrou no lobby. Vá ao ponto de largada.', 'success');
          else if (k === 'leave')  toast('Você saiu do lobby.', 'info');
          else                     toast('Operação concluída.', 'success');
          POST('refresh_lobbies', {});
          if (k === 'join') switchTab('lobbies');
        } else {
          const errCode = typeof r.data === 'string'
            ? r.data
            : (r.data && r.data.err) || '';
          toast(errMsg(errCode), 'error');
        }
        break;
      }
      case 'ranking': {
        const d = msg.data || {};
        renderRanking(d.data || []);
        break;
      }
      case 'history': {
        renderHistory(msg.data || []);
        break;
      }
      case 'results': {
        const d = msg.data || {};
        const rs = d.results || [];
        if (rs.length === 0) { toast('Sem resultados nessa sessão.', 'info'); return; }
        const lines = rs.map((r) =>
          `#${r.placement} ${r.nick} — ${fmtTime(r.total_time_ms)}` +
          (r.payout > 0 ? ` (${fmtMoney(r.payout)})` : ''));
        toast(lines.join(' · '), 'info');
        break;
      }
      case 'race_finish': {
        const d = msg.data || {};
        toast(`Você terminou em #${d.placement || '?'} — ${fmtMoney(d.payout || 0)}`,
              d.placement === 1 ? 'success' : 'info');
        break;
      }

      // Editor relays
      // OBS: editor_open NAO e enviado pelo cliente Lua quando o painel fecha
      // automaticamente — aqui so atualizamos estado se chegar (caso painel
      // ja estivesse aberto na aba editor).
      case 'editor_open': {
        state.editor.open = true;
        state.editor.draft = msg.data || {};
        break;
      }
      case 'editor_draft': {
        state.editor.draft = msg.data || {};
        break;
      }
      case 'editor_phase': {
        const phase = (msg.data && msg.data.phase) || 'idle';
        if (phase === 'grid') toast('Fase 1: posicione os carros da grade.', 'info');
        if (phase === 'cps')  toast('Fase 2: dirija marcando checkpoints.', 'info');
        if (phase === 'meta') {
          toast('Fase 3: preencha os metadados da pista.', 'info');
          switchTab('editor');
        }
        break;
      }
      case 'editor_close': {
        state.editor.open = false;
        state.editor.draft = null;
        break;
      }
    }
  });

  // ─── Bindings ───────────────────────────────────────────────────────────

  document.addEventListener('click', (ev) => {
    const t = ev.target.closest('[data-action], [data-tab]');
    if (!t) return;
    if (t.dataset.tab) { switchTab(t.dataset.tab); return; }
    const a = t.dataset.action;
    if (a === 'close')             POST('close', {});
    if (a === 'refresh')           POST('refresh_lobbies', {});
    if (a === 'modal-close')       closeModal();
    if (a === 'modal-create')      submitCreate();
    if (a === 'refresh-ranking') {
      POST('ranking', { kind: $('#ranking-kind').value || 'sprint',
                        mode: $('#ranking-mode').value || 'wins' });
    }
    if (a === 'refresh-history') {
      POST('history', { kind: $('#history-kind').value || '',
                        mode: $('#history-mode').value || '' });
    }
    if (a === 'editor-start')      editorStart();
    if (a === 'editor-phase-grid') POST('editor_phase', { phase: 'grid' });
    if (a === 'editor-phase-cps')  POST('editor_phase', { phase: 'cps' });
    if (a === 'editor-phase-meta') POST('editor_phase', { phase: 'meta' });
    if (a === 'editor-discard')    POST('editor_discard', {});
    if (a === 'editor-save')       editorSave();
  });

  document.addEventListener('keydown', (ev) => {
    if (!state.open) return;
    if (ev.key === 'Escape') {
      if (!$('#modal-create').classList.contains('hidden')) { closeModal(); return; }
      POST('close', {});
    }
  });

  document.addEventListener('input', (ev) => {
    if (ev.target.id === 'tracks-search')      { state.tracksFilter = ev.target.value; renderTracks(); }
    if (ev.target.id === 'tracks-filter-kind') { state.tracksKind   = ev.target.value; renderTracks(); }
  });
})();
