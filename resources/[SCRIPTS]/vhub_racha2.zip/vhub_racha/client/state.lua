-- client/state.lua - estado local da corrida + State Bag listener.

VHubRachaLocal = {
  open_nui = false,
  open_editor = false,
  bag = {},
  pending = nil,
  confirmed = false,
  active = nil,
  _cp_blips = {},
  editor_draft = nil,
}

local L = VHubRachaLocal

local function local_bag_name()
  return ('player:%d'):format(GetPlayerServerId(PlayerId()))
end

local function apply_bag(value)
  if type(value) == 'table' then
    L.bag = value
    L.confirmed = value.confirmed == true
  else
    L.bag = {}
    L.confirmed = false
  end
  TriggerEvent('vhub_racha:local:bag_update', L.bag)
end

AddStateBagChangeHandler('vhub_racha', nil, function(bag_name, _key, value)
  if bag_name ~= local_bag_name() then return end
  apply_bag(value)
end)

CreateThread(function()
  while GetPlayerServerId(PlayerId()) <= 0 do Wait(250) end
  apply_bag(LocalPlayer.state.vhub_racha)
end)

function VHubRachaLocal.active_race() return L.active end
function VHubRachaLocal.set_active(a) L.active = a end
function VHubRachaLocal.clear_active() L.active = nil end

function VHubRachaLocal.set_pending(p)
  L.pending = p
  L.confirmed = false
end

function VHubRachaLocal.clear_pending()
  L.pending = nil
  L.confirmed = false
end

exports('isInRace', function() return L.active ~= nil and L.bag.state == 'racing' end)
exports('isInLobby', function() return L.pending ~= nil end)
exports('currentKind', function() return L.bag and L.bag.kind or nil end)
exports('driftScore', function() return L.bag and L.bag.drift_score or 0 end)
exports('isReady', function() return VHubRachaBoot and VHubRachaBoot.READY == true end)
