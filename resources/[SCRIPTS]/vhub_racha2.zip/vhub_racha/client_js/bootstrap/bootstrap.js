(function(){
  'use strict';
  const PREFIX = '[vhub_racha][client-js]';
  const nowMs = () => (typeof GetGameTimer === 'function' ? GetGameTimer() : Date.now());

  // Polyfill: runtime JS do client expoe apenas RegisterNuiCallbackType + on('__cfx_nui:...').
  // Replica a assinatura Lua RegisterNUICallback(type, cb) combinando as duas natives.
  if (typeof globalThis.RegisterNUICallback !== 'function') {
    globalThis.RegisterNUICallback = function(type, cb) {
      try { RegisterNuiCallbackType(type); } catch (_) {}
      try { on('__cfx_nui:' + type, cb); } catch (_) {}
    };
  }

  globalThis.VHubRachaBoot = globalThis.VHubRachaBoot || {
    READY: false,
    AUTH_READY: false,
    vHub: null,
    user_id: null,
    char_id: null,
    start_ms: nowMs(),
    ready_at: 0,
    _on_ready: [],
  };
  const B = globalThis.VHubRachaBoot;

  function onReady(fn, name) {
    if (typeof fn !== 'function') return;
    if (B.READY) {
      try { fn(); } catch (err) { console.log(`${PREFIX} callback ${name||'?'} erro: ${err}`); }
      return;
    }
    B._on_ready.push({ fn, name: name || '?' });
  }
  globalThis.VHubRachaBoot.onReady = onReady;

  function _emit_ready() {
    if (B.READY) return;
    B.READY = true;
    B.ready_at = nowMs();
    console.log(`${PREFIX} pronto em ${B.ready_at - B.start_ms}ms (rodando ${B._on_ready.length} callbacks)`);
    for (const entry of B._on_ready) {
      try { entry.fn(); } catch (err) { console.log(`${PREFIX} ${entry.name} erro: ${err}`); }
    }
    B._on_ready = [];
    try { emit('vhub_racha:boot:ready'); } catch(e) { /* best-effort */ }
  }

  function try_resolve_vhub() {
    try {
      if (globalThis.vHub && typeof globalThis.vHub === 'object') { B.vHub = globalThis.vHub; return true; }
    } catch (e) {}
    try {
      if (typeof exports === 'object' && exports.vhub && typeof exports.vhub.getVHub === 'function') {
        const ref = exports.vhub.getVHub();
        if (ref && typeof ref === 'object') { B.vHub = ref; return true; }
      }
    } catch (e) {}
    return false;
  }

  onNet('vHub:initDone', (user_id, char_id, primeiro_spawn) => {
    B.user_id = Number(user_id) || null;
    B.char_id = Number(char_id) || null;
    B.AUTH_READY = true;
    if (try_resolve_vhub()) _emit_ready();
  });

  onNet('vHub:localReady', (user_id, char_id, primeiro_spawn) => {
    B.user_id = Number(user_id) || B.user_id;
    B.char_id = Number(char_id) || B.char_id;
    B.AUTH_READY = true;
    if (try_resolve_vhub()) _emit_ready();
  });

  // Solicita re-emissao do initDone (cobre race conditions)
  setTimeout(() => { try { emitNet('vhub_racha:request_initDone'); } catch(e) {} }, 200);
  setTimeout(() => { if (!B.READY) try { emitNet('vhub_racha:request_initDone'); } catch(e) {} }, 3200);
  setTimeout(() => { if (!B.READY) try { emitNet('vhub_racha:request_initDone'); } catch(e) {} }, 8200);

  // Polling fallback: checa State Bag e resolve vHub até 60s
  let checks = 0;
  const intervalId = setInterval(() => {
    if (B.READY || checks >= 120) {
      if (!B.READY && checks >= 120) {
        const gv = globalThis.vHub ? 'ok' : 'nil';
        const exports_ok = (typeof exports === 'object' && typeof exports.vhub === 'object');
        const sb = (globalThis.LocalPlayer && LocalPlayer.state) ? LocalPlayer.state : null;
        const sb_ready = sb && sb.vhub_pronto === true;
        console.log(`${PREFIX} vhub indisponivel apos 60s. debug: global_vhub=${gv} exports_vhub=${exports_ok} auth_ready=${B.AUTH_READY} state_ready=${sb_ready} b_user=${B.user_id} b_char=${B.char_id}`);
      }
      clearInterval(intervalId);
      return;
    }
    const sb = (globalThis.LocalPlayer && LocalPlayer.state) ? LocalPlayer.state : null;
    if (sb && sb.vhub_pronto === true) {
      B.AUTH_READY = true;
      B.user_id = Number(sb.vhub_uid) || B.user_id;
      B.char_id = Number(sb.vhub_char_id) || B.char_id;
      try_resolve_vhub();
      _emit_ready();
      clearInterval(intervalId);
      return;
    }
    if (try_resolve_vhub()) {
      const sb2 = (globalThis.LocalPlayer && LocalPlayer.state) ? LocalPlayer.state : null;
      if (sb2 && sb2.vhub_pronto === true) {
        B.AUTH_READY = true;
        B.user_id = Number(sb2.vhub_uid) || B.user_id;
        B.char_id = Number(sb2.vhub_char_id) || B.char_id;
        _emit_ready();
        clearInterval(intervalId);
        return;
      }
    }
    checks++;
  }, 500);

  on('onResourceStop', (res) => {
    try { if (res !== GetCurrentResourceName()) return; } catch(e) {}
    B.READY = false;
  });

  globalThis.VHubRachaBoot.emitReady = _emit_ready;
})();
