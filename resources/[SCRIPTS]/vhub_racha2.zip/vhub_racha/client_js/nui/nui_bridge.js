(function(){
  'use strict';
  const TELEMETRY_INTERVAL = 250; // ms
  const PREFIX = '[vhub_racha][nui-bridge]';

  const Cfg = (globalThis.VHubRachaCfg || { HUD: { USE_NUI: true }, COUNTDOWN_MS: 7000 });
  const E = {
    RACE_PREPARE: 'vhub_racha:race:prepare',
    RACE_START: 'vhub_racha:race:start',
    RACE_FINISH: 'vhub_racha:race:finish',
    RACE_ABORT: 'vhub_racha:race:abort',
    LOBBY_CONFIRM: 'vhub_racha:lobby:confirm',
    LOBBY_JOIN: 'vhub_racha:lobby:join',
    LOBBY_LEAVE: 'vhub_racha:lobby:leave',
    NUI_READY: 'nui_ready',
  };

  let lastBagJson = '';
  let lastTelemetryMs = 0;
  let localStartedMs = 0;
  const VHubRachaNui = { ready: false, ready_at: 0, href: '' };

  function enabled() { return Cfg && Cfg.HUD && Cfg.HUD.USE_NUI === true; }
  function sendNui(obj) { try { SendNuiMessage(JSON.stringify(obj)); } catch(e) { /* noop */ } }

  function sendBagIfChanged(bag) {
    try {
      const j = JSON.stringify(bag || {});
      if (j === lastBagJson) return;
      lastBagJson = j;
      if (enabled()) sendNui({ type: 'vhub_racha.bag_update', bag: bag || {} });
    } catch (e) {}
  }

  function cpTelemetry(active) {
    try {
      if (!active) return null;
      const ped = PlayerPedId();
      const pos = GetEntityCoords(ped);
      const cp = (active.track && active.track.checkpoints && active.track.checkpoints.length > 0)
        ? active.track.checkpoints[((Math.max(1, Number(active.cp_index) || 1) - 1) % active.track.checkpoints.length)]
        : null;
      if (!cp) return null;
      const dx = cp.x - pos.x; const dy = cp.y - pos.y;
      const dist = Math.sqrt(dx*dx + dy*dy);
      return dist;
    } catch (e) { return null; }
  }

  function speedKmh() {
    try {
      const ped = PlayerPedId();
      const veh = (typeof VHubRachaVeh === 'object' && typeof VHubRachaVeh.ped_vehicle === 'function')
        ? VHubRachaVeh.ped_vehicle(ped)
        : 0;
      if (!veh) return 0;
      return Math.max(0, Math.floor((typeof VHubRachaVeh !== 'undefined' && VHubRachaVeh.speed_kmh) ? VHubRachaVeh.speed_kmh(veh) || 0 : 0));
    } catch (e) { return 0; }
  }

  // Handlers from server
  onNet(E.RACE_PREPARE, (payload) => {
    try {
      if (!enabled() || typeof payload !== 'object') return;
      const track = payload.track || {};
      const cp_total = (track.checkpoints && track.checkpoints.length) ? (track.checkpoints.length * (Number(payload.laps) || Number(track.laps) || 1)) : 1;
      sendNui({ action: 'hud_show', data: {
        cps_total: cp_total,
        laps_total: Number(payload.laps) || Number(track.laps) || 1,
        players_total: Number(payload.players_total) || 0,
        mode: payload.mode || 'rankeada',
      }});
      sendNui({ action: 'hud_countdown', data: { seconds: Math.max(1, Math.ceil((Number(payload.countdown) || Cfg.COUNTDOWN_MS || 7000) / 1000)) } });
    } catch (e) { console.log(PREFIX, e); }
  });

  onNet(E.RACE_START, (_payload) => {
    if (!enabled()) return;
    localStartedMs = GetGameTimer();
    sendNui({ action: 'hud_start', data: { elapsed_ms: 0, _local: true, _force: true } });
  });

  onNet(E.RACE_FINISH, (payload) => { if (!enabled()) return; sendNui({ action: 'hud_finish', data: payload || {} }); localStartedMs = 0; });
  onNet(E.RACE_ABORT, (_reason) => { if (!enabled()) return; sendNui({ action: 'hud_hide' }); localStartedMs = 0; });

  // Bridge events and telemetry loop
  setInterval(() => {
    try {
      if (!enabled()) return;
      const L = (typeof VHubRachaLocal !== 'undefined') ? VHubRachaLocal : null;
      const active = L && typeof L.active_race === 'function' ? L.active_race() : null;
      const bag = L && L.bag ? L.bag : {};
      if (active && !active.aborted && !active.finished) {
        const now = GetGameTimer();
        if (now - lastTelemetryMs >= TELEMETRY_INTERVAL) {
          lastTelemetryMs = now;
          const dist = cpTelemetry(active);
          const started = localStartedMs > 0 ? localStartedMs : now;
          const cp_total = Number(active.cp_total) || Number(bag.cp_total) || 0;
          const cp_next = Number(active.cp_index) || ((Number(bag.cp_done) || 0) + 1);
          sendNui({ type: 'vhub_racha.telemetry', payload: {
            state: bag.state || (active.started_ms && active.started_ms > 0 ? 'racing' : 'warmup'),
            elapsed_ms: localStartedMs > 0 ? Math.max(0, now - started) : 0,
            speed_kmh: speedKmh(),
            cp_index: cp_next,
            cp_total: cp_total,
            cp_done: Number(bag.cp_done) || Math.max(0, cp_next - 1),
            lap: Number(bag.lap) || 1,
            laps: Number(active.laps) || Number(bag.laps) || 1,
            placement: Number(bag.placement) || 0,
            players_total: Number(bag.players_total) || Number(active.players_total) || 0,
            drift_score: Number(active.drift_score) || Number(bag.drift_score) || 0,
            drift_combo: Number(active.drift_combo) || Number(bag.drift_combo) || 1,
            distance_m: dist,
          }});
        }
      }
    } catch (e) { /* best-effort */ }
  }, TELEMETRY_INTERVAL);

  // NUI callbacks
  try {
    RegisterNUICallback('nui_ready', (data, cb) => {
      VHubRachaNui.ready = true; VHubRachaNui.ready_at = GetGameTimer(); VHubRachaNui.href = (data && data.href) ? String(data.href) : '';
      cb({ ok: true, use_nui: enabled(), ready: true });
    });

    RegisterNUICallback('vhub_racha.action', (data, cb) => {
      data = (typeof data === 'object') ? data : {};
      const action = String(data.action || '');
      if (action === 'confirm_presence') emitNet(E.LOBBY_CONFIRM, data.inst_id || '');
      else if (action === 'leave_lobby') emitNet(E.LOBBY_LEAVE, data.inst_id || '');
      else if (action === 'request_join') emitNet(E.LOBBY_JOIN, data.inst_id || '');
      else { cb({ ok: false, err: 'acao_invalida' }); return; }
      cb({ ok: true });
    });

    RegisterNUICallback('vhub_racha.request_sync', (_data, cb) => { sendBagIfChanged((typeof VHubRachaLocal !== 'undefined' && VHubRachaLocal.bag) ? VHubRachaLocal.bag : {}); cb({ ok: true }); });
  } catch (e) { console.log(PREFIX, 'RegisterNUICallback failed', e); }
})();
