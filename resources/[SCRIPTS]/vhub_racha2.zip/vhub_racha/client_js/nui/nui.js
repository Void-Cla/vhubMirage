(function(){
  'use strict';
  const PREFIX = '[vhub_racha][nui-client-js]';
  const OPEN_COMMANDS = ['racha', 'vhub_racha'];
  const E = {
    NUI_OPEN: 'vhub_racha:nui:open',
    NUI_OPENED: 'vhub_racha:nui:opened',
    NUI_REFRESH: 'vhub_racha:nui:refresh',
    NUI_RESULT: 'vhub_racha:nui:result',
    NUI_RANKING: 'vhub_racha:nui:ranking',
    NUI_RANKING_DATA: 'vhub_racha:nui:ranking_data',
    NUI_HISTORY: 'vhub_racha:nui:history',
    NUI_HISTORY_DATA: 'vhub_racha:nui:history_data',
    NUI_RESULTS: 'vhub_racha:nui:results',
    NUI_RESULTS_DATA: 'vhub_racha:nui:results_data',
    LOBBY_CREATE: 'vhub_racha:lobby:create',
    LOBBY_JOIN: 'vhub_racha:lobby:join',
    LOBBY_LEAVE: 'vhub_racha:lobby:leave',
    LOBBY_CANCEL: 'vhub_racha:lobby:cancel',
    LOBBY_PENDING: 'vhub_racha:lobby:pending',
    LOBBY_CONFIRM: 'vhub_racha:lobby:confirm',
    LOBBY_CONFIRMED: 'vhub_racha:lobby:confirmed',
    LOBBY_FORCE_START: 'vhub_racha:lobby:force_start',
    NOTIFY: 'vhub_racha:notify',
    EDITOR_OPEN: 'vhub_racha:editor:open',
    EDITOR_OPENED: 'vhub_racha:editor:opened',
    EDITOR_PHASE: 'vhub_racha:editor:phase',
    EDITOR_ADD_GRID: 'vhub_racha:editor:add_grid',
    EDITOR_ADD_CP: 'vhub_racha:editor:add_cp',
    EDITOR_UNDO: 'vhub_racha:editor:undo',
    EDITOR_SAVE: 'vhub_racha:editor:save',
    EDITOR_DISCARD: 'vhub_racha:editor:discard',
    EDITOR_DRAFT: 'vhub_racha:editor:draft',
  };
  const PENDING_TTL_FALLBACK = 300000;
  let pending = null;
  let pendingBlip = 0;
  let lastConfirmMs = 0;

  function localState() {
    globalThis.VHubRachaLocal = globalThis.VHubRachaLocal || {};
    return globalThis.VHubRachaLocal;
  }

  function notifyNative(msg) {
    try {
      BeginTextCommandThefeedPost('STRING');
      AddTextComponentSubstringPlayerName(String(msg || ''));
      EndTextCommandThefeedPostTicker(false, true);
    } catch (e) { console.log(PREFIX, e); }
  }

  function sendNui(obj) {
    try { SendNuiMessage(JSON.stringify(obj)); }
    catch (e) { console.log(PREFIX, e); }
  }

  function n(v, fallback) {
    const x = Number(v);
    return Number.isFinite(x) ? x : fallback;
  }

  function zoneOf(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const zone = {
      x: n(raw.x, NaN),
      y: n(raw.y, NaN),
      z: n(raw.z, NaN),
      radius: n(raw.radius, 18.0),
      z_tol: n(raw.z_tol, 5.0),
    };
    return Number.isFinite(zone.x) && Number.isFinite(zone.y) && Number.isFinite(zone.z) ? zone : null;
  }

  function coordsOf(entity) {
    const v = GetEntityCoords(entity, false);
    return {
      x: Array.isArray(v) ? v[0] : n(v.x, 0),
      y: Array.isArray(v) ? v[1] : n(v.y, 0),
      z: Array.isArray(v) ? v[2] : n(v.z, 0),
    };
  }

  function clearPending() {
    pending = null;
    if (pendingBlip && DoesBlipExist(pendingBlip)) RemoveBlip(pendingBlip);
    pendingBlip = 0;
  }

  function setPending(data, source) {
    data = (data && typeof data === 'object') ? data : {};
    const zone = zoneOf(data.ready_zone);
    if (!zone) {
      notifyNative('Lobby pendente, mas sem zona de largada valida.');
      return;
    }

    clearPending();
    const ttl = n(data.pending_ttl_ms, 0);
    pending = {
      inst_id: String(data.inst_id || ''),
      ready_zone: zone,
      deadline: GetGameTimer() + (ttl > 0 ? ttl : PENDING_TTL_FALLBACK),
      track_label: String(data.track_label || data.track_id || 'Largada'),
      source: source || 'event',
      confirmed: false,
    };

    pendingBlip = AddBlipForCoord(zone.x, zone.y, zone.z);
    SetBlipSprite(pendingBlip, 38);
    SetBlipColour(pendingBlip, 5);
    SetBlipScale(pendingBlip, 1.0);
    SetBlipRoute(pendingBlip, true);
    SetBlipRouteColour(pendingBlip, 5);
    BeginTextCommandSetBlipName('STRING');
    AddTextComponentSubstringPlayerName(`Mirage Racha - ${pending.track_label}`);
    EndTextCommandSetBlipName(pendingBlip);

    const L = localState();
    L.open_nui = false;
    SetNuiFocus(false, false);
    sendNui({ action: 'close' });
    sendNui({ type: 'vhub_racha.lobby.pending', data: data });
    notifyNative('Lobby pendente: va ate o ponto de largada e pressione E.');
  }

  function drawText(text, x, y, scale, r, g, b, a, center) {
    SetTextFont(7);
    SetTextScale(0.0, scale || 0.44);
    SetTextColour(r || 255, g || 255, b || 255, a || 240);
    SetTextOutline();
    SetTextDropShadow();
    SetTextCentre(center === true);
    BeginTextCommandDisplayText('STRING');
    AddTextComponentSubstringPlayerName(String(text || ''));
    EndTextCommandDisplayText(x, y);
  }

  function insideReadyZone(zone, pos) {
    const dz = Math.abs(pos.z - zone.z);
    if (dz > zone.z_tol) return false;
    const dx = pos.x - zone.x;
    const dy = pos.y - zone.y;
    return ((dx * dx) + (dy * dy)) <= (zone.radius * zone.radius);
  }

  function renderPending() {
    if (!pending) return;
    const zone = pending.ready_zone;
    const pos = coordsOf(PlayerPedId());
    const dx = pos.x - zone.x;
    const dy = pos.y - zone.y;
    const d2 = (dx * dx) + (dy * dy);
    const remaining = Math.max(0, pending.deadline - GetGameTimer());
    drawText(`Tempo p/ confirmar: ${Math.ceil(remaining / 1000)}s`, 0.03, 0.02, 0.44, 255, 255, 255, 240, false);

    if (d2 <= (300 * 300)) {
      const r = zone.radius || 18.0;
      DrawMarker(1, zone.x, zone.y, zone.z - 1.0, 0, 0, 0, 0, 0, 0, r * 2.0, r * 2.0, 0.8, 243, 181, 58, 90, false, false, 2, false, null, null, false);
      DrawMarker(28, zone.x, zone.y, zone.z + 1.5, 0, 0, 0, 0, 0, 0, r * 1.8, r * 1.8, 4.0, 243, 181, 58, 50, false, false, 2, false, null, null, false);

      if (!pending.confirmed && insideReadyZone(zone, pos)) {
        const screen = GetScreenCoordFromWorldCoord(zone.x, zone.y, zone.z + 2.0);
        if (Array.isArray(screen) && screen[0]) drawText('[E] confirmar presenca', screen[1], screen[2], 0.55, 255, 255, 255, 240, true);
      }
    }

    if (!pending.confirmed && IsControlJustReleased(0, 38) && (GetGameTimer() - lastConfirmMs) > 800) {
      lastConfirmMs = GetGameTimer();
      emitNet(E.LOBBY_CONFIRM, pending.inst_id);
    }
  }

  setTick(renderPending);

  function handleBag(value) {
    if (!value || typeof value !== 'object') {
      clearPending();
      return;
    }
    if (value.state === 'pending' && value.ready_zone && !pending) {
      setPending({
        inst_id: value.inst_id,
        ready_zone: value.ready_zone,
        pending_ttl_ms: value.pending_ttl_ms,
        track_label: value.track_id || 'Largada',
      }, 'bag');
    } else if (value.state === 'warmup' || value.state === 'racing' || value.confirmed === true) {
      clearPending();
    }
  }

  try {
    AddStateBagChangeHandler('vhub_racha', null, (bagName, _key, value) => {
      const localBag = `player:${GetPlayerServerId(PlayerId())}`;
      if (bagName !== localBag) return;
      handleBag(value);
    });
    setInterval(() => {
      try {
        if (!pending && globalThis.LocalPlayer && LocalPlayer.state) handleBag(LocalPlayer.state.vhub_racha);
      } catch (e) {}
    }, 1000);
  } catch (e) { console.log(PREFIX, 'state bag fallback indisponivel', e); }

  function requireReady(cb) {
    if (!(globalThis.VHubRachaBoot && VHubRachaBoot.READY)) {
      notifyNative('Mirage Racha ainda nao esta pronto.');
      if (cb) cb({ ok: false });
      return false;
    }
    return true;
  }

  function openPanel() {
    if (!requireReady()) return;
    emitNet(E.NUI_OPEN);
  }

  try {
    onNet(E.NOTIFY, (msg, _kind) => notifyNative(msg));

    onNet(E.NUI_OPENED, (data) => {
      const L = localState();
      L.open_nui = true;
      SetNuiFocus(true, true);
      sendNui({ action: 'open', data: data || {} });
    });

    onNet(E.NUI_REFRESH, (data) => {
      if (!localState().open_nui) return;
      sendNui({ action: 'refresh', data: data || {} });
    });

    onNet(E.NUI_RESULT, (payload) => {
      if (!localState().open_nui) return;
      sendNui({ action: 'result', data: payload || {} });
    });

    onNet(E.NUI_RANKING_DATA, (data) => {
      if (localState().open_nui) sendNui({ action: 'ranking', data: data || {} });
    });

    onNet(E.NUI_HISTORY_DATA, (data) => {
      if (localState().open_nui) sendNui({ action: 'history', data: data || {} });
    });

    onNet(E.NUI_RESULTS_DATA, (data) => {
      if (localState().open_nui) sendNui({ action: 'results', data: data || {} });
    });

    onNet(E.LOBBY_PENDING, (data) => {
      setPending(data || {}, 'event');
    });

    onNet(E.LOBBY_CONFIRMED, (data) => {
      if (pending) pending.confirmed = true;
      clearPending();
      notifyNative('Presenca confirmada. Aguarde o inicio.');
      sendNui({ type: 'vhub_racha.lobby.confirmed', data: data || {} });
    });

    onNet(E.EDITOR_OPENED, (draft) => {
      const L = localState();
      L.open_editor = true;
      L.editor_draft = draft || {};
      if (L.open_nui) {
        L.open_nui = false;
        SetNuiFocus(false, false);
        sendNui({ action: 'close' });
      }
      notifyNative('Editor ativo. Use comandos in-game: E adicionar | H undo | G proxima fase.');
    });

    onNet(E.EDITOR_DRAFT, (draft) => {
      const L = localState();
      L.editor_draft = draft || {};
      if (L.open_nui) sendNui({ action: 'editor_draft', data: draft || {} });
    });

    onNet(E.EDITOR_PHASE, (payload) => {
      const L = localState();
      const phase = (payload && payload.phase) || 'idle';
      if (L.open_nui) sendNui({ action: 'editor_phase', data: payload || {} });
      if (phase === 'meta' && !L.open_nui) emitNet(E.NUI_OPEN);
    });
  } catch (e) { console.log(PREFIX, 'event handler error', e); }

  try {
    RegisterNUICallback('close', (_data, cb) => {
      const L = localState();
      L.open_nui = false;
      SetNuiFocus(false, false);
      sendNui({ action: 'close' });
      cb({ ok: true });
    });

    RegisterNUICallback('editor_close', (_data, cb) => {
      const L = localState();
      L.open_editor = false;
      SetNuiFocus(false, false);
      sendNui({ action: 'editor_close' });
      cb({ ok: true });
    });

    RegisterNUICallback('create', (data, cb) => { if (!requireReady(cb)) return; emitNet(E.LOBBY_CREATE, data || {}); cb({ ok: true }); });
    RegisterNUICallback('join', (data, cb) => { if (!requireReady(cb)) return; emitNet(E.LOBBY_JOIN, (data && data.inst_id) || ''); cb({ ok: true }); });
    RegisterNUICallback('leave', (data, cb) => { emitNet(E.LOBBY_LEAVE, (data && data.inst_id) || ''); cb({ ok: true }); });
    RegisterNUICallback('cancel', (data, cb) => { emitNet(E.LOBBY_CANCEL, (data && data.inst_id) || ''); cb({ ok: true }); });
    RegisterNUICallback('confirm', (data, cb) => { if (!requireReady(cb)) return; emitNet(E.LOBBY_CONFIRM, (data && data.inst_id) || ''); cb({ ok: true }); });
    RegisterNUICallback('force_start', (data, cb) => { if (!requireReady(cb)) return; emitNet(E.LOBBY_FORCE_START, (data && data.inst_id) || ''); cb({ ok: true }); });
    RegisterNUICallback('refresh_lobbies', (_data, cb) => { emitNet(E.NUI_OPEN); cb({ ok: true }); });

    RegisterNUICallback('ranking', (data, cb) => { emitNet(E.NUI_RANKING, data || {}); cb({ ok: true }); });
    RegisterNUICallback('history', (data, cb) => { emitNet(E.NUI_HISTORY, data || {}); cb({ ok: true }); });
    RegisterNUICallback('results', (data, cb) => { emitNet(E.NUI_RESULTS, (data && data.history_id) || 0); cb({ ok: true }); });

    RegisterNUICallback('editor_open', (_d, cb) => { emitNet(E.EDITOR_OPEN); cb({ ok: true }); });
    RegisterNUICallback('editor_phase', (d, cb) => { emitNet(E.EDITOR_PHASE, d || {}); cb({ ok: true }); });
    RegisterNUICallback('editor_add_grid', (_d, cb) => { emitNet(E.EDITOR_ADD_GRID); cb({ ok: true }); });
    RegisterNUICallback('editor_add_cp', (_d, cb) => { emitNet(E.EDITOR_ADD_CP); cb({ ok: true }); });
    RegisterNUICallback('editor_undo', (_d, cb) => { emitNet(E.EDITOR_UNDO); cb({ ok: true }); });
    RegisterNUICallback('editor_save', (d, cb) => { if (!requireReady(cb)) return; emitNet(E.EDITOR_SAVE, d || {}); cb({ ok: true }); });
    RegisterNUICallback('editor_discard', (_d, cb) => { emitNet(E.EDITOR_DISCARD); cb({ ok: true }); });
  } catch (e) { console.log(PREFIX, 'RegisterNUICallback error', e); }

  try {
    for (const command of OPEN_COMMANDS) RegisterCommand(command, openPanel, false);
  } catch (e) { console.log(PREFIX, e); }
})();
