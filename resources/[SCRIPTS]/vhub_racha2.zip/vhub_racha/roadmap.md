# PROMPT MASTER — Conversão Arquitetural do `vhub_racha` para JS + HTML + CSS Modular (Padrão vHub Mirage)

> Objetivo:
>
> Converter TODO o client do `vhub_racha` para uma arquitetura moderna, extremamente organizada, modular, resiliente, otimizada e compatível com os padrões internos do ecossistema vHub Mirage.
>
> IMPORTANTE:
>
> NÃO recriar o projeto.
>
> NÃO reinventar lógica funcional já existente.
>
> NÃO quebrar compatibilidade com o servidor atual.
>
> O foco é:
>
> * converter client Lua → JS;
> * reorganizar completamente a NUI;
> * separar responsabilidades;
> * reduzir spaghetti code;
> * reduzir tamanho de arquivos;
> * melhorar performance;
> * melhorar resiliência;
> * melhorar manutenção;
> * melhorar debugging;
> * melhorar UX/UI;
> * manter padrão visual oficial do vHub Mirage;
> * manter baixo resmon;
> * preservar integrações atuais do vHub.
>
> O projeto deve parecer:
>
> * software enterprise;
> * framework AAA;
> * engine modular;
> * arquitetura premium;
> * código profissional de longa duração.
>
> E NÃO:
>
> * script improvisado;
> * spaghetti code;
> * monolito Lua;
> * NUI genérica;
> * frontend bagunçado.

---

# 1. STACK OBRIGATÓRIA

## Server

### MANTER:

* Lua;
* callbacks atuais;
* integração vHub;
* padrão de logs;
* padrão de segurança;
* padrão de exports.

---

## Client Gameplay

### CONVERTER PARA:

* JavaScript puro;
* modular;
* sem frameworks pesados;
* sem React;
* sem Vue;
* sem Angular.

---

## NUI

### UTILIZAR:

* HTML;
* CSS;
* JavaScript puro.

---

## Node.js

### PERMITIDO SOMENTE:

* módulos leves;
* bibliotecas utilitárias;
* organização;
* helpers;
* validação;
* easing;
* event bus;
* matemática;
* UUIDs;
* ferramentas leves.

---

## PROIBIDO:

* backend separado;
* websocket server;
* express server;
* serviços externos;
* APIs externas;
* Docker;
* PM2;
* microservices;
* infraestrutura externa.

---

# 2. FILOSOFIA ARQUITETURAL OBRIGATÓRIA

## O projeto DEVE seguir:

### Clean Architecture

### Separation of Concerns

### Single Responsibility Principle

### Baixo Acoplamento

### Alta Coesão

### Modularidade Real

### Renderização Isolada

### Estado Centralizado

### Renderer desacoplado

### UX cinematográfica

### Performance first

### Resmon first

### Native-first

### vHub style guide

---

# 3. REGRAS ABSOLUTAS

## PROIBIDO:

* arquivos gigantes;
* HTML com 1000+ linhas;
* JS com 1500+ linhas;
* CSS monolítico;
* lógica inline;
* CSS inline;
* spaghetti code;
* loops espalhados;
* globals descontroladas;
* callbacks aninhados;
* lógica duplicada;
* HUD misturada com gameplay;
* renderer misturado com menu;
* funções com múltiplas responsabilidades;
* código sem semântica;
* nomes genéricos;
* comentários excessivos;
* texto hardcoded;
* lógica em HTML.

---

# 4. LIMITE DE TAMANHO DE ARQUIVOS

## Ideal:

```text
150 ~ 350 linhas
```

---

## Máximo aceitável:

```text
600 linhas
```

---

## PROIBIDO:

```text
1000+
1500+
2000+ linhas
```

---

# 5. NOMENCLATURA OBRIGATÓRIA

## Utilizar nomenclatura:

* coesa;
* semântica;
* previsível;
* legível;
* profissional.

---

## EXEMPLO CORRETO

```js
RaceLobbyManager
CheckpointRenderer
SpectatorCameraController
RaceHudBridge
```

---

## EXEMPLO ERRADO

```js
manager2
testRender
systemFinal
mainControllerUltimate
```

---

# 6. COMENTÁRIOS

## TODOS os comentários devem:

* estar em PT-BR;
* possuir no máximo 1 linha;
* serem objetivos;
* explicar intenção;
* nunca descrever óbvio.

---

## EXEMPLO CORRETO

```js
// Atualiza apenas checkpoints visíveis
```

---

## EXEMPLO ERRADO

```js
// Essa função aqui serve para atualizar os checkpoints que aparecem na tela do jogador dependendo da distância e da posição atual do veículo
```

---

# 7. ESTRUTURA OBRIGATÓRIA DO PROJETO

```text
vhub_racha/

fxmanifest.lua

package.json

shared/
  config/
  constants/
  enums/
  locales/
  contracts/

server/
  (MANTER LUA)

client/
  bootstrap/
  runtime/
  renderer/
  race/
  lobby/
  spectator/
  editor/
  hud/
  systems/
  utils/

nui/
  assets/
  core/
  shared/
  screens/
```

---

# 8. ESTRUTURA NUI OBRIGATÓRIA

```text
nui/

  assets/
    fonts/
    icons/
    audio/
    textures/
    particles/

  core/
    router.js
    store.js
    events.js
    animations.js
    transitions.js
    nui.js
    audio.js

  shared/
    components/
    modals/
    notifications/
    cards/
    buttons/
    glass/
    layouts/

  screens/
    home/
    lobby/
    race/
    hud/
    ranking/
    history/
    editor/
    spectator/
    settings/
```

---

# 9. REGRA MAIS IMPORTANTE DA NUI

## CADA TELA = MÓDULO ISOLADO

Cada tela DEVE possuir:

```text
screen-name/

  index.html
  style.css
  app.js
  scripts.js
```

---

# 10. RESPONSABILIDADE DE CADA ARQUIVO

## index.html

Responsável APENAS por:

* estrutura;
* containers;
* semântica;
* layout base.

---

## style.css

Responsável APENAS por:

* visual;
* glassmorphism;
* responsividade;
* animações CSS;
* identidade visual.

---

## app.js

Responsável por:

* bootstrap da tela;
* integração NUI;
* eventos principais;
* ciclo de vida;
* estado principal.

---

## scripts.js

Responsável por:

* helpers;
* componentes locais;
* renderizações secundárias;
* utilidades;
* animações JS.

---

# 11. SISTEMA DE ESTADO

## Criar:

```text
nui/core/store.js
```

---

## O store deve controlar:

* lobby;
* corrida;
* player;
* ranking;
* histórico;
* spectator;
* HUD;
* editor.

---

## PROIBIDO:

```js
window.currentRace = {}
```

---

## OBRIGATÓRIO:

```js
Store.set('race', data)
Store.get('race')
```

---

# 12. SISTEMA DE EVENTOS

## Criar:

```text
nui/core/events.js
```

---

## Objetivo:

* desacoplamento;
* comunicação limpa;
* evitar imports circulares.

---

## Exemplo:

```js
Events.emit('race:start')
Events.on('race:start')
```

---

# 13. CONVERSÃO DO CLIENT LUA

## Converter o client para módulos separados.

---

# Estrutura obrigatória:

```text
client/

  bootstrap/
    init.js

  runtime/
    tick.js
    state.js
    events.js

  renderer/
    checkpoints.js
    particles.js
    markers.js
    lod.js
    cinematic.js
    text3d.js

  race/
    manager.js
    logic.js
    timing.js
    laps.js
    checkpoints.js

  lobby/
    manager.js
    ready.js
    presence.js

  spectator/
    manager.js
    cameras.js
    autoTv.js
    freecam.js

  editor/
    manager.js
    grid.js
    checkpoints.js
    metadata.js
    preview.js

  hud/
    bridge.js

  systems/
    audio.js
    notifications.js
    transitions.js

  utils/
    math.js
    lerp.js
    natives.js
    debug.js
    zones.js
```

---

# 14. SISTEMA DE RENDERIZAÇÃO

## O renderer DEVE ser COMPLETAMENTE isolado.

---

## Renderer NÃO pode:

* abrir menu;
* alterar ranking;
* manipular SQL;
* controlar lobby;
* gerenciar recompensa.

---

# 15. RENDERER DE TOTENS

## Criar:

```text
client/renderer/checkpoints.js
```

---

## Responsabilidade exclusiva:

* renderização;
* distância;
* LOD;
* partículas;
* glow;
* alpha;
* animações;
* otimização.

---

## O renderer deve:

* dormir fora de range;
* usar distância adaptativa;
* reduzir partículas à distância;
* pausar efeitos invisíveis;
* evitar Draw excessivo.

---

# 16. SISTEMA DE LOOP

## Criar:

```text
client/runtime/tick.js
```

---

## PROIBIDO:

* loops infinitos espalhados;
* Wait(0) desnecessário;
* threads duplicadas.

---

## OBRIGATÓRIO:

* scheduler central;
* frequência adaptativa;
* sleep inteligente;
* pause automático.

---

# 17. SISTEMA HUD

## HUD deve ser separada em módulos.

---

## Estrutura:

```text
screens/hud/

  components/
    timer/
    position/
    lap/
    checkpoint/
    speed/
```

---

## Cada componente:

* independente;
* reutilizável;
* pequeno;
* sem lógica global.

---

# 18. SISTEMA LOBBY

## Criar tela exclusiva:

```text
screens/lobby/
```

---

## Separar:

* lista jogadores;
* ready check;
* host;
* timer;
* confirmação;
* status;
* espectadores.

---

# 19. SISTEMA EDITOR

## O editor DEVE ser totalmente modular.

---

## Separar:

* grid;
* checkpoints;
* preview;
* metadata;
* exportação;
* validação.

---

# 20. SISTEMA SPECTATOR

## Separar:

* cameras;
* auto TV;
* troca jogador;
* freecam;
* cinematic.

---

# 21. SISTEMA DE LOCALIZAÇÃO

## Criar:

```text
shared/locales/
```

---

## PROIBIDO:

texto hardcoded.

---

## OBRIGATÓRIO:

```js
Locale.t('race.starting')
```

---

# 22. PADRÃO VISUAL OBRIGATÓRIO (GUARDIÃO UI)

## O visual DEVE seguir:

* Liquid Glass;
* Areia Dourada;
* Blur;
* Glow suave;
* Partículas leves;
* UI cinematográfica;
* visual premium.

---

## Inspirado em:

* Forza Horizon;
* GT7;
* The Crew;
* NFS Heat;
* Midnight Club.

---

# 23. PROIBIDO VISUALMENTE

* azul neon genérico;
* HUD opaca;
* UI quadrada;
* fontes ruins;
* texto técnico;
* cores saturadas;
* gradientes exagerados;
* poluição visual.

---

# 24. SISTEMA DE LOGS (PADRÃO VHUB)

## TODOS logs devem:

* possuir contexto;
* possuir módulo;
* possuir nível;
* possuir semântica clara.

---

## Exemplo:

```js
Logger.info('[Lobby] Jogador entrou no lobby')
Logger.warn('[Race] Checkpoint inválido')
Logger.error('[Renderer] Falha ao carregar partículas')
```

---

# 25. SISTEMA DE CALLBACKS (PADRÃO VHUB)

## Callbacks devem:

* ser resilientes;
* validados;
* seguros;
* sem race condition;
* sem callback hell.

---

# 26. SEGURANÇA

## O client:

* nunca valida sozinho;
* nunca define recompensa;
* nunca define ranking;
* nunca define vitória.

---

## O server continua:

* authoritative;
* validando;
* sincronizando.

---

# 27. META DE PERFORMANCE

## Idle:

```text
0.00 ~ 0.03ms
```

---

## Em corrida:

```text
0.05 ~ 0.15ms
```

---

## Máximo aceitável:

```text
0.30ms
```

---

# 28. OBJETIVO FINAL

## O resultado deve parecer:

* sistema AAA;
* arquitetura enterprise;
* framework profissional;
* código de longa duração;
* engine modular.

---

# 29. RESULTADO ESPERADO

Após conversão, o `vhub_racha` deve possuir:

* renderer organizado;
* HUD premium;
* arquivos pequenos;
* responsabilidades claras;
* fácil manutenção;
* fácil debugging;
* fácil profiling;
* NUI modular;
* UX cinematográfica;
* baixo resmon;
* código resiliente;
* código seguro;
* arquitetura limpa;
* sem spaghetti code;
* sem monólitos gigantes;
* sem arquivos absurdos.

---

# 30. REGRA FINAL ABSOLUTA

## A IA NÃO deve:

* reinventar o projeto;
* mudar regras de gameplay sem necessidade;
* quebrar integração vHub;
* criar dependência pesada;
* usar frameworks gigantes;
* criar backend externo;
* criar build pipeline complexo.

---

# 31. A IA DEVE:

* converter Lua client → JS modular;
* modularizar a NUI;
* separar responsabilidades;
* preservar funcionamento;
* melhorar renderização;
* melhorar performance;
* melhorar organização;
* melhorar UX;
* melhorar debugging;
* manter padrão vHub Mirage;
* manter Guardião UI;
* reduzir linhas;
* reduzir duplicação;
* reduzir acoplamento;
* aumentar resiliência;
* facilitar manutenção futura.
