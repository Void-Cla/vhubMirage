# MIGRATION JS — vhub_racha

Resumo rápido

- Esta pasta adiciona um scaffold `client_js/` com versões iniciais em JS de:
  - `bootstrap` (handshake robusto)
  - `nui/nui.js` (NUI callbacks)
  - `nui/nui_bridge.js` (telemetria e bridge NUI)

Objetivo

- Permitir conversão incremental do client Lua → JS mantendo fallback Lua até que
  a migração esteja pronta para ativação.

Ativar o client JS (passos opcionais, seguros)

1. Faça backup do resource (já realizado conforme informado).
2. Teste os módulos JS localmente lendo logs do cliente (F8) — eles usam prefixos:
   - `[vhub_racha][client-js]` (bootstrap)
   - `[vhub_racha][nui-bridge]` (bridge)
   - `[vhub_racha][nui-client-js]` (nui callbacks)
3. Para ativar o client JS substitua as entradas `client_scripts` no `fxmanifest.lua` por:

```lua
client_scripts {
  'client_js/bootstrap/bootstrap.js',
  'client_js/core/index.js', -- (futuro)
  'client_js/nui/nui.js',
  'client_js/nui/nui_bridge.js',
  -- outros modules convertidos
}
```

4. Reinicie o recurso e observe F8 para mensagens de ready/debug.

Observações importantes

- Os arquivos em `shared/` permanecem em Lua. Comunicação entre Lua shared e client JS
  não é automática. Para compartilhar constantes/CFG entre Lua e JS você deve:
  - exportar via server (exports) ou
  - mover a config para um arquivo JSON em `shared/` e carregá-lo via `LoadResourceFile` em ambos os ambientes.

- Mantivemos o servidor em Lua (recomendado pelo roadmap). A migração JS foca no cliente.

Próximos passos sugeridos (pos-migração incremental)

- Converter `client/bootstrap.lua` por completo para `client_js/bootstrap` (feito: versão inicial).
- Converter `client/nui_bridge.lua` e `client/nui.lua` (feito: versões iniciais).
- Converter módulos de gameplay (`race`, `lobby`, `modes/*`, `hud`, `sync`, `editor`) em etapas, testando cada um.
- Criar `client_js/core/events.js` e `client_js/core/store.js` para centralizar constantes e estado.
- Atualizar `fxmanifest.lua` apenas quando cobertura de testes for satisfatória.

Se quiser, eu atualizo o `fxmanifest.lua` automaticamente e converto `client/bootstrap.lua` e `client/nui_bridge.lua` completamente para substituir as versões Lua. Diga se quer que eu faça a troca agora.
